"""Core check execution — extract → detect → translate → match → highlight."""

from __future__ import annotations

from playwright.sync_api import Page, Locator

from .config_loader import CheckDef, GlobalConfig
from .language import detect_language, translate_to_english
from .text_utils import normalize, semantic_score


class CheckResult:
    def __init__(self, passed: bool, actual_text: str, match_type: str):
        self.passed      = passed
        self.actual_text = actual_text
        self.match_type  = match_type    # 'exact' | 'semantic' | 'none' | 'not_found'


def run_check(page: Page, check: CheckDef, config: GlobalConfig) -> CheckResult:
    locator = page.locator(check.locator)

    try:
        locator.first.wait_for(state="attached", timeout=10_000)
    except Exception:
        print(f"  ❌ No element found for locator: {check.locator}")
        return CheckResult(False, "element not found", "not_found")

    count         = locator.count()
    expected_norm = normalize(check.expected)
    best_score    = 0.0
    best_idx      = -1
    best_display  = ""

    for i in range(count):
        elem = locator.nth(i)
        raw  = elem.inner_text().strip()
        if not raw:
            continue

        lang = detect_language(raw)
        print(f"  [#{i}] lang={lang!r} | {raw[:80]}")

        if lang != "en":
            print(f"  [#{i}] Translating {lang!r} → en…")
            display = translate_to_english(raw)
            _inject_translation(elem, display)
        else:
            display = raw

        candidate = normalize(display)

        # Exact substring match
        if expected_norm in candidate:
            print(f"  [#{i}] ✅ Exact match")
            _highlight(elem, match_type="exact")
            return CheckResult(True, display, "exact")

        # Track best semantic candidate
        score = semantic_score(candidate, expected_norm)
        print(f"  [#{i}] semantic_score={score:.3f}")
        if score > best_score:
            best_score, best_idx, best_display = score, i, display

    # Semantic fallback
    print(f"  Best semantic score: {best_score:.3f} (threshold {config.semantic_threshold})")
    if best_score >= config.semantic_threshold and best_idx >= 0:
        print(f"  [#{best_idx}] ✅ Semantic match accepted")
        _highlight(locator.nth(best_idx), match_type="semantic")
        return CheckResult(True, best_display, "semantic")

    print("  ❌ No match")
    return CheckResult(False, best_display, "none")


# ── DOM helpers ───────────────────────────────────────────────────────────────

def _inject_translation(elem: Locator, translated: str) -> None:
    escaped = translated.replace("\\", "\\\\").replace("`", "\\`")
    try:
        elem.evaluate(f"el => {{ el.innerText = `{escaped}`; }}")
    except Exception:
        pass


def _highlight(elem: Locator, match_type: str) -> None:
    """Highlight the matched element.

    Exact match  → solid yellow background + green outline + label
    Semantic match → light yellow background + red outline + label
    
    Both highlight the whole element — trying to regex-match inside innerHTML
    breaks on elements that contain nested tags, entities, or translated text.
    """
    if match_type == "exact":
        bg      = "yellow"
        outline = "3px solid green"
        label   = "✓ exact match"
        color   = "green"
    else:
        bg      = "lightyellow"
        outline = "3px solid red"
        label   = "✓ semantic match"
        color   = "red"

    try:
        elem.evaluate(f"""el => {{
            el.scrollIntoView({{behavior:'auto', block:'center'}});
            el.style.backgroundColor = '{bg}';
            el.style.outline = '{outline}';
            el.style.borderRadius = '3px';
            const tag = document.createElement('span');
            tag.textContent = ' [{label}]';
            tag.style.cssText = 'background:{color};color:white;font-size:11px;'
                              + 'padding:1px 4px;border-radius:3px;margin-left:4px';
            el.appendChild(tag);
        }}""")
    except Exception:
        pass