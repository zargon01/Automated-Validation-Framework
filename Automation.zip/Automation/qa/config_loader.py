"""Loads config.yaml (global) and a checks/*.yaml (suite) into typed dataclasses.

GlobalConfig  — browser, thresholds, paths
SuiteConfig   — url, page class name, checks list
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import List
import yaml


@dataclass
class CheckDef:
    name: str
    locator: str
    expected: str


@dataclass
class GlobalConfig:
    screenshot_dir:          str
    excel_file:              str
    semantic_threshold:      float
    translation_timeout_s:   int
    translation_poll_s:      float
    after_translate_wait_ms: int
    headless:                bool
    slow_mo:                 int


@dataclass
class SuiteConfig:
    url:    str
    page:   str           # filename stem in pages/ e.g. "ms365_pdp"
    checks: List[CheckDef]


def load_global(path: str = "config.yaml") -> GlobalConfig:
    with open(path, encoding="utf-8") as f:
        raw = yaml.safe_load(f)
    return GlobalConfig(
        screenshot_dir          = raw.get("screenshot_dir", "screenshots"),
        excel_file              = raw.get("excel_file", "regions_checks.xlsx"),
        semantic_threshold      = raw.get("semantic_threshold", 0.60),
        translation_timeout_s   = raw.get("translation_timeout_s", 30),
        translation_poll_s      = raw.get("translation_poll_s", 0.5),
        after_translate_wait_ms = raw.get("after_translate_wait_ms", 3000),
        headless                = raw.get("headless", False),
        slow_mo                 = raw.get("slow_mo", 100),
    )


def load_suite(path: str) -> SuiteConfig:
    with open(path, encoding="utf-8") as f:
        raw = yaml.safe_load(f)
    checks = [CheckDef(**c) for c in raw.get("checks", [])]
    return SuiteConfig(
        url    = raw["url"],
        page   = raw["page"],
        checks = checks,
    )