"""Orchestrator — wires every module together. Contains no business logic."""

from __future__ import annotations
import os

from playwright.sync_api import Page

from .config_loader import GlobalConfig, SuiteConfig
from .browser import BrowserManager
from .page_loader import load_page
from .check_runner import run_check
from .reporter import load_regions, write_results
from .text_utils import get_model


def run(global_cfg: GlobalConfig, suite: SuiteConfig) -> None:
    get_model()
    os.makedirs(global_cfg.screenshot_dir, exist_ok=True)

    regions = load_regions(global_cfg, suite)
    if not regions:
        print("❌ No regions found in Excel. Add region codes in column A.")
        return

    print(f"\n📋 {len(regions)} region(s): {[r['region'] for r in regions]}")
    print(f"📄 Page class: {suite.page}")
    print(f"🔍 Checks: {[c.name for c in suite.checks]}\n")

    page_obj = load_page(suite.page)

    with BrowserManager(global_cfg) as bm:
        page: Page = bm.new_page()

        for entry in regions:
            region = entry["region"]
            row    = entry["row"]
            url    = suite.url.format(region=region)

            print(f"\n{'='*60}")
            print(f"▶  {region}  →  {url}")
            print(f"{'='*60}")

            page.goto(url, wait_until="domcontentloaded")

            # Page-specific setup (popup, english, accordion, waits…)
            page_obj.setup(page, global_cfg)

            # Run every check defined in the suite yaml
            results    = []
            all_passed = True

            for check in suite.checks:
                print(f"\n  🔍 {check.name}")
                result = run_check(page, check, global_cfg)
                results.append(result)

                status = "✅ PASS" if result.passed else "❌ FAIL"
                tag    = f"[{result.match_type}]" if result.passed else ""
                print(f"  {status} {tag}: {check.name}")

                if not result.passed:
                    all_passed = False

            # Screenshot
            shot_path = os.path.join(
                global_cfg.screenshot_dir, f"PDP Family page {region}.png"
            )
            page.screenshot(path=shot_path, full_page=True)
            print(f"\n  📌 Screenshot: {shot_path}")

            # Write results back to Excel
            write_results(global_cfg, row, results)
            print(f"  {'🎉 All passed' if all_passed else '⚠️  Some checks failed'} for {region}")

    print(f"\n✅ Results written to {global_cfg.excel_file}")