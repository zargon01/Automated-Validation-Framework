"""Excel I/O — reads regions, writes PASS/FAIL results.

Column layout (1-based):
  Col 1       : region code  (input)
  Col 2 + i*2 : actual text  (output) for check i
  Col 3 + i*2 : PASS / FAIL  (output) for check i
"""

from __future__ import annotations
from typing import List

from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font

from .config_loader import GlobalConfig, SuiteConfig, CheckDef
from .check_runner import CheckResult

_FILL_PASS = PatternFill("solid", start_color="C6EFCE")
_FILL_FAIL = PatternFill("solid", start_color="FFC7CE")
_FONT_PASS = Font(name="Arial", size=10, bold=True, color="276221")
_FONT_FAIL = Font(name="Arial", size=10, bold=True, color="9C0006")
_FONT_HDR  = Font(name="Arial", size=10, bold=True)


def _actual_col(i: int) -> int: return 2 + i * 2
def _result_col(i: int) -> int: return 3 + i * 2


def load_regions(global_cfg: GlobalConfig, suite: SuiteConfig) -> list[dict]:
    wb = load_workbook(global_cfg.excel_file)
    ws = wb.active

    if not ws.cell(1, 1).value:
        _write_headers(ws, suite.checks)
        wb.save(global_cfg.excel_file)

    regions = []
    for row in ws.iter_rows(min_row=2):
        val = row[0].value
        if val:
            regions.append({"row": row[0].row, "region": str(val).strip()})

    wb.close()
    return regions


def write_results(global_cfg: GlobalConfig, row: int, results: List[CheckResult]) -> None:
    wb = load_workbook(global_cfg.excel_file)
    ws = wb.active

    for i, result in enumerate(results):
        ws.cell(row=row, column=_actual_col(i)).value = result.actual_text
        cell = ws.cell(row=row, column=_result_col(i))
        cell.value = "PASS" if result.passed else "FAIL"
        cell.fill  = _FILL_PASS if result.passed else _FILL_FAIL
        cell.font  = _FONT_PASS if result.passed else _FONT_FAIL

    wb.save(global_cfg.excel_file)
    wb.close()


def _write_headers(ws, checks: List[CheckDef]) -> None:
    ws.cell(1, 1).value = "Region"
    ws.cell(1, 1).font  = _FONT_HDR
    for i, check in enumerate(checks):
        ws.cell(1, _actual_col(i)).value = f"{check.name} – actual text"
        ws.cell(1, _actual_col(i)).font  = _FONT_HDR
        ws.cell(1, _result_col(i)).value = f"{check.name} – result"
        ws.cell(1, _result_col(i)).font  = _FONT_HDR