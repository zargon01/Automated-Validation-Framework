from playwright.sync_api import sync_playwright

def normalize(text):
    return (
        text.replace("\u00A0", " ")
            .replace("\n", " ")
            .strip()
            .lower()
    )

def close_popup(page, timeout=5000):
    print("🔒 Waiting for popup...")
    try:
        popup_btn = page.locator('xpath=/html/body/div[2]/div[2]/div/div/div[1]/button')
        popup_btn.wait_for(state="visible", timeout=timeout)
        popup_btn.click()
        print("✅ Popup closed")
    except:
        print("ℹ️ No popup appeared")

def run():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False, slow_mo=200)
        page = browser.new_page()
        print("➡️ Navigating to Microsoft 365 Family PDP page...")
        page.goto("https://www.microsoft.com/en-us/microsoft-365/p/microsoft-365-family/cfq7ttc0k5dm")

        close_popup(page)

        checks = [
            {
                "name": "Promo text",
                "locator": '[data-automation-test-id^="buy-box-promo"] p',
                "expected": "Subscription automatically renews at the regular price and selected term, unless cancelled in Microsoft account. See",
                "expand": False,
            },
            {
                "name": "Accordion AI text",
                "locator": "li div.collapse div.accordion-body p",
                "expected": "you also get extensive usage on advanced AI experiences",
                "expand": True,
            },
        ]

        for check in checks:
            print(f"\n🔍 Checking: {check['name']}")
            if check["expand"]:
                btn = page.locator("button.btn-collapse").first
                btn.wait_for(state="visible", timeout=10000)
                btn.click()
                page.locator("div.collapse.show").first.wait_for(timeout=10000)
                print("✅ Accordion expanded")

            locator = page.locator(check["locator"])
            locator.first.wait_for(state="attached", timeout=10000)

            match_found = False
            for i in range(locator.count()):
                elem = locator.nth(i)
                text = elem.inner_text()
                if normalize(check["expected"]) in normalize(text):
                    # Highlight verified text by injecting JS directly
                    js_code = f"""
                    el => {{
                        const regex = new RegExp({repr(check['expected'])}, 'gi');
                        el.innerHTML = el.innerHTML.replace(regex, match => '<span class="highlighted">'+match+'</span>');
                    }}
                    """
                    elem.evaluate(js_code)
                    match_found = True

            if not match_found:
                raise Exception(f"❌ {check['name']} check failed")
            print(f"✅ Passed: {check['name']}")

        print("\n🎉 Both checks passed successfully!")

        # Inject CSS for highlight
        page.add_style_tag(content="""
            .highlighted {
                background-color: yellow;
                border: 2px solid red;
                border-radius: 3px;
            }
        """)

        # Take full-page screenshot
        screenshot_path = "familyPDP_highlighted.png"
        page.screenshot(path=screenshot_path, full_page=True)
        print(f"📌 Highlighted screenshot saved: {screenshot_path}")

        page.wait_for_timeout(5000)
        browser.close()


if __name__ == "__main__":
    run()