from playwright.sync_api import sync_playwright
from sentence_transformers import SentenceTransformer, util
from langdetect import detect
import os

# ✅ Configure Hugging Face local cache
os.environ["HF_HOME"] = r"C:\Notes\Research Try Page Automation"
os.environ["TRANSFORMERS_CACHE"] = r"C:\Notes\Research Try Page Automation\models"
os.environ["SENTENCE_TRANSFORMERS_CACHE"] = r"C:\Notes\Research Try Page Automation\sentence-transformers"

# Initialize multilingual model locally
model = SentenceTransformer("sentence-transformers/distiluse-base-multilingual-cased-v2")

def normalize(text):
    return text.replace("\u00A0", " ").replace("\n", " ").strip().lower()

def close_popup(page, timeout=5000):
    print("🔒 Waiting for popup...")
    try:
        popup_btn = page.locator('xpath=/html/body/div[2]/div[2]/div/div/div[1]/button')
        popup_btn.wait_for(state="visible", timeout=timeout)
        popup_btn.click()
        print("✅ Popup closed")
    except:
        print("ℹ️ No popup appeared")

def translate_page_if_needed(page, timeout=5000):
    """Trigger Chrome's translate to English if the page is not in English."""
    print("🌐 Checking for translate popup...")
    try:
        translate_btn = page.locator('xpath=//button[contains(text(),"Translate")]')
        translate_btn.wait_for(state="visible", timeout=timeout)
        translate_btn.click()
        print("✅ Page translated to English via Chrome popup")
        page.wait_for_timeout(3000)  # wait for translation to finish
    except:
        print("ℹ️ No translate popup appeared or already in English")

def semantic_match_local(reference_text, extracted_text, threshold=0.75):
    """Compare texts: exact match if English, else semantic similarity"""
    try:
        lang = detect(extracted_text)
    except:
        lang = "en"  # fallback
    
    if lang == "en":
        return normalize(reference_text) in normalize(extracted_text), 1.0
    else:
        # If non-English, do semantic similarity (after translation)
        ref_emb = model.encode(reference_text, convert_to_tensor=True)
        text_emb = model.encode(extracted_text, convert_to_tensor=True)
        sim = util.pytorch_cos_sim(ref_emb, text_emb).item()
        return sim >= threshold, sim

def run():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False, slow_mo=100)
        page = browser.new_page()
        url = "https://www.microsoft.com/ar-ae/microsoft-365/p/microsoft-365-family/cfq7ttc0k5dm"
        print(f"➡️ Navigating to {url} ...")
        page.goto(url)

        close_popup(page)
        translate_page_if_needed(page)

        checks = [
            {
                "name": "Promo text",
                "locator": '[data-automation-test-id^="buy-box-promo"] p',
                "expected": "Subscription automatically renews at the regular price and selected term, unless cancelled in Microsoft account. See",
                "expand": False,
            },
            {
                "name": "Accordion AI text",
                "locator": "li div.collapse div.accordion-body p",
                "expected": "you also get extensive usage on advanced AI experiences",
                "expand": True,
            },
        ]

        highlighted_elements = []

        for check in checks:
            print(f"\n🔍 Checking: {check['name']}")
            
            # Expand accordion if needed
            if check["expand"]:
                try:
                    btn = page.locator("button.btn-collapse").first
                    btn.wait_for(state="visible", timeout=10000)
                    btn.click()
                    page.locator("div.collapse.show").first.wait_for(timeout=10000)
                    print("✅ Accordion expanded")
                except:
                    print(f"⚠️ Could not expand accordion for {check['name']}")
            
            locator = page.locator(check["locator"])
            try:
                locator.first.wait_for(state="attached", timeout=10000)
            except:
                print(f"⚠️ Locator not found for {check['name']}, skipping...")
                continue

            match_found = False
            for i in range(locator.count()):
                elem = locator.nth(i)
                text = elem.inner_text()
                match, sim = semantic_match_local(check["expected"], text)
                if match:
                    highlighted_elements.append((elem, check["expected"]))
                    match_found = True
                    print(f"✅ Passed: {check['name']} (Similarity: {sim:.2f})")
                    break

            if not match_found:
                print(f"❌ {check['name']} check failed")

        # Highlight verified texts via JS injection
        for elem, expected_text in highlighted_elements:
            element_handle = elem.element_handle()
            page.evaluate(
                """({element, text}) => {
                    const safeText = text.replace(/[.*+?^${}()|[\\]\\\\]/g,'\\\\$&');
                    const regex = new RegExp(safeText, 'gi');
                    element.innerHTML = element.innerHTML.replace(regex, match => `<span style="background-color: yellow;">${match}</span>`);
                }""",
                {"element": element_handle, "text": expected_text}
            )

        # Full page screenshot
        page.screenshot(path="familyPDP_full.png", full_page=True)
        print("📸 Full page screenshot saved: familyPDP_full.png")

        page.screenshot(path="familyPDP_highlighted.png", full_page=True)
        print("📌 Highlighted screenshot saved: familyPDP_highlighted.png")

        page.wait_for_timeout(2000)
        browser.close()

if __name__ == "__main__":
    run()