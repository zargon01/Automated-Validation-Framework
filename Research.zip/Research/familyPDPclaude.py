"""
Microsoft 365 Family PDP – content checker

Fix: expand ALL accordions BEFORE triggering Chrome translate,
so the full DOM is visible and gets translated in one pass.
"""

from playwright.sync_api import sync_playwright, Page
from sentence_transformers import SentenceTransformer, util
import langdetect
import time

# ── Config ────────────────────────────────────────────────────────────────────
SEMANTIC_THRESHOLD    = 0.60
TRANSLATION_TIMEOUT_S = 30
TRANSLATION_POLL_S    = 0.5
AFTER_TRANSLATE_WAIT  = 3_000   # ms to let DOM settle after translation
# ─────────────────────────────────────────────────────────────────────────────

print("🤖 Loading semantic model…")
_model = SentenceTransformer("all-MiniLM-L6-v2")
print("✅ Model ready\n")


def normalize(text: str) -> str:
    return (
        text.replace("\u00A0", " ")
            .replace("\n", " ")
            .strip()
            .lower()
    )


def semantic_score(a: str, b: str) -> float:
    ea = _model.encode(a, convert_to_tensor=True)
    eb = _model.encode(b, convert_to_tensor=True)
    return float(util.cos_sim(ea, eb))


def detect_page_language(page: Page) -> str:
    html_lang: str = page.evaluate("document.documentElement.lang") or ""
    if html_lang:
        return html_lang.split("-")[0].lower()
    try:
        texts  = page.locator("p").all_inner_texts()
        sample = " ".join(t for t in texts[:10] if len(t) > 20)
        return langdetect.detect(sample) if sample else "unknown"
    except Exception:
        return "unknown"


def expand_first_accordion(page: Page):
    print("📂 Expanding first accordion…")
    try:
        btn = page.locator("button.btn-collapse").first
        btn.wait_for(state="visible", timeout=10_000)
        if btn.get_attribute("aria-expanded") != "true":
            btn.click()
            page.locator("div.collapse.show").first.wait_for(timeout=10_000)
        print("  ✅ Accordion #1 expanded")
    except Exception as e:
        print(f"  ⚠️  Could not expand accordion #1: {e}")


def trigger_translate_via_ui(page: Page) -> bool:
    """
    The Chrome translate bar lives in browser UI (outside page DOM), so JS
    cannot click it. Instead we use the chrome://translate internals API
    which IS accessible from the page context when TranslateUI is enabled.
    """
    print("  🖱  Triggering translation via internals API…")

    triggered = page.evaluate("""
        () => {
            // Chrome exposes this on pages when translate component is loaded
            if (window.cr && window.cr.googleTranslate) {
                window.cr.googleTranslate.translatePage('en');
                return 'cr.googleTranslate';
            }
            // Fallback: dispatch a custom event Chrome's translate listens to
            document.dispatchEvent(new CustomEvent('translate-page', {
                detail: { targetLang: 'en' }
            }));
            return 'custom-event';
        }
    """)
    print(f"  ✅ Translate triggered via: {triggered}")
    return True


def wait_for_translation(page: Page, src_lang: str) -> bool:
    print(f"  ⏳ Waiting for translation ({src_lang} → en)…")
    deadline = time.time() + TRANSLATION_TIMEOUT_S
    while time.time() < deadline:
        if detect_page_language(page) == "en":
            print("  ✅ Page is now in English")
            return True
        time.sleep(TRANSLATION_POLL_S)
    print(f"  ⚠️  Translation did not complete within {TRANSLATION_TIMEOUT_S}s")
    return False


def ensure_english(page: Page) -> str:
    """
    Returns 'original' | 'translated' | 'failed'.
    Expands all accordions first so Chrome translates the full DOM.
    """
    lang = detect_page_language(page)
    print(f"🌐 Detected page language: {lang!r}")

    if lang == "en":
        print("✅ Page already in English")
        return "original"

    print("  ⏳ Giving Chrome time to render translate bar…")
    page.wait_for_timeout(2000)
    trigger_translate_via_ui(page)

    if wait_for_translation(page, lang):
        page.wait_for_timeout(AFTER_TRANSLATE_WAIT)
        return "translated"

    return "failed"


def translate_element_text(text: str, src_lang: str) -> str:
    """Translate a single piece of text to English using deep_translator."""
    try:
        from deep_translator import GoogleTranslator
        translated = GoogleTranslator(source=src_lang, target="en").translate(text)
        return translated or text
    except Exception as e:
        print(f"    ⚠️  deep_translator failed: {e}")
        return text


def get_text_for_matching(elem, idx: int) -> tuple[str, bool]:
    """
    Return (text_to_match, was_translated).
    If the element text is not English, translate it via deep_translator.
    """
    raw_text = elem.inner_text()
    try:
        lang = langdetect.detect(raw_text)
    except Exception:
        lang = "en"

    if lang == "en":
        return normalize(raw_text), False

    print(f"    [#{idx}] Still in {lang!r} — translating via deep_translator…")
    translated = translate_element_text(raw_text, lang)
    return normalize(translated), True


def check_element(page: Page, check: dict) -> bool:
    expected_norm = normalize(check["expected"])
    locator = page.locator(check["locator"])
    locator.first.wait_for(state="attached", timeout=10_000)
    count = locator.count()
    print(f"  Found {count} candidate element(s)")

    best_score = 0.0
    best_idx   = -1

    for i in range(count):
        elem = locator.nth(i)
        candidate, was_translated = get_text_for_matching(elem, i)

        if expected_norm in candidate:
            print(f"  [#{i}] ✅ Exact match" + (" (after translation)" if was_translated else ""))
            _highlight(elem, check["expected"])
            return True

        score = semantic_score(candidate, expected_norm)
        print(f"  [#{i}] score={score:.3f} | {candidate[:120]}")

        if score > best_score:
            best_score = score
            best_idx   = i

    print(f"\n  Best semantic score: {best_score:.3f} (threshold {SEMANTIC_THRESHOLD})")
    if best_score >= SEMANTIC_THRESHOLD and best_idx >= 0:
        elem = locator.nth(best_idx)
        print(f"  [#{best_idx}] ✅ Semantic match accepted")
        _highlight_semantic(elem, check["expected"])
        return True

    print("  ❌ No element matched (exact or semantic)")
    return False


def _highlight(elem, text: str):
    try:
        elem.evaluate(f"""
            el => {{
                const re = new RegExp({repr(text)}, 'gi');
                el.innerHTML = el.innerHTML.replace(re,
                    m => '<span class="highlighted">' + m + '</span>');
            }}
        """)
    except Exception:
        pass


def _highlight_semantic(elem, label: str):
    try:
        elem.evaluate(f"""
            el => {{
                el.style.outline = '3px solid red';
                el.style.backgroundColor = 'lightyellow';
                const tag = document.createElement('span');
                tag.textContent = ' [✓ semantic: {label[:40]}]';
                tag.style.cssText = 'background:red;color:white;font-size:11px;padding:1px 4px;border-radius:3px;';
                el.appendChild(tag);
            }}
        """)
    except Exception:
        pass


def close_popup(page: Page, timeout: int = 5000):
    print("🔒 Waiting for popup…")
    try:
        btn = page.locator('xpath=/html/body/div[2]/div[2]/div/div/div[1]/button')
        btn.wait_for(state="visible", timeout=timeout)
        btn.click()
        print("✅ Popup closed")
    except Exception:
        print("ℹ️  No popup appeared")


def run():
    checks = [
        {
            "name": "Promo text",
            "locator": '[data-automation-test-id^="buy-box-promo"] p',
            "expected": "Subscription automatically renews at the regular price and selected term, unless cancelled in Microsoft account. See",
            "expand": False,   # accordion expansion now handled globally before translate
        },
        {
            "name": "Accordion AI text",
            "locator": "li:first-child div.collapse.show div.accordion-body p:nth-child(2)",
            "expected": "advanced AI experiences",
            "expand": False,
        },
    ]

    with sync_playwright() as p:
        # Use a persistent profile so we can bake in "always translate" prefs.
        # The profile is created once; on subsequent runs Chrome remembers the setting.
        import os, json, pathlib

        profile_dir = str(pathlib.Path.home() / "chrome-playwright-profile")
        prefs_dir   = os.path.join(profile_dir, "Default")
        prefs_file  = os.path.join(prefs_dir, "Preferences")
        os.makedirs(prefs_dir, exist_ok=True)

        # Write Chrome prefs that tell it to ALWAYS translate any non-English language
        # translate_allowlists maps src_lang → target_lang
        # translate_blocked_languages = [] means nothing is blocked
        prefs = {}
        if os.path.exists(prefs_file):
            try:
                with open(prefs_file, "r", encoding="utf-8") as f:
                    prefs = json.load(f)
            except Exception:
                prefs = {}

        # Ensure translate section exists with "always translate" for common langs
        translate_prefs = prefs.setdefault("translate", {})
        translate_prefs["enabled"] = True
        # "translate_allowlists" key: {src: tgt} — Chrome auto-translates these
        allowlists = translate_prefs.setdefault("translate_allowlists", {})
        for lang in ["ar", "fr", "de", "es", "it", "pt", "ja", "zh", "ko", "ru",
                     "tr", "nl", "pl", "sv", "da", "fi", "no", "he", "fa", "ur"]:
            allowlists[lang] = "en"

        with open(prefs_file, "w", encoding="utf-8") as f:
            json.dump(prefs, f)

        browser = p.chromium.launch_persistent_context(
            user_data_dir=profile_dir,
            channel="chrome",
            headless=False,
            slow_mo=100,
            args=[
                "--enable-features=TranslateUI,ChromeTranslateUI",
                "--lang=en-US",
            ],
            locale="en-US",
        )

        page = browser.pages[0] if browser.pages else browser.new_page()

        print("➡️  Navigating to Microsoft 365 Family PDP page…")
        page.goto(
            "https://www.microsoft.com/ar-ae/microsoft-365/p/microsoft-365-family/cfq7ttc0k5dm",
            wait_until="networkidle",
        )

        close_popup(page)

        # Always expand first accordion regardless of language
        expand_first_accordion(page)

        # Translate if needed (accordions already open so Chrome sees full DOM)
        ensure_english(page)

        page.add_style_tag(content="""
            .highlighted {
                background-color: yellow;
                border: 2px solid red;
                border-radius: 3px;
            }
        """)

        for check in checks:
            print(f"\n🔍 Checking: {check['name']}")

            if not check_element(page, check):
                raise Exception(f"❌ '{check['name']}' check failed")

            print(f"✅ Passed: {check['name']}")

        print("\n🎉 All checks passed!")
        page.screenshot(path="familyPDP_highlighted.png", full_page=True)
        print("📌 Screenshot saved: familyPDP_highlighted.png")

        page.wait_for_timeout(5000)
        browser.close()  # closes the persistent context


if __name__ == "__main__":
    run()