"""
Microsoft 365 Family PDP – multi-region content checker

Reads regions from an Excel file, runs checks for each region,
writes results (pass/fail + actual text) back to the same file,
and saves a screenshot per region.

Excel columns:
  region | test1 | test1-expected-text | test1-actual-text | test1-result |
         | test2 | test2-expected-text | test2-actual-text | test2-result
"""

import os
import json
import pathlib
import time

from playwright.sync_api import sync_playwright, Page, BrowserContext
from sentence_transformers import SentenceTransformer, util
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font
import langdetect

# ── Config ────────────────────────────────────────────────────────────────────
EXCEL_FILE            = "regions_checks.xlsx"   # path to your Excel file
SCREENSHOT_DIR        = "screenshots"           # folder for screenshots
BASE_URL              = "https://www.microsoft.com/{region}/microsoft-365/p/microsoft-365-family/cfq7ttc0k5dm"
SEMANTIC_THRESHOLD    = 0.60
TRANSLATION_TIMEOUT_S = 30
TRANSLATION_POLL_S    = 0.5
AFTER_TRANSLATE_WAIT  = 3_000
# ─────────────────────────────────────────────────────────────────────────────

# Excel column indices (1-based)
COL_REGION            = 1
COL_TEST1_NAME        = 2
COL_TEST1_EXPECTED    = 3
COL_TEST1_ACTUAL      = 4
COL_TEST1_RESULT      = 5
COL_TEST2_NAME        = 6
COL_TEST2_EXPECTED    = 7
COL_TEST2_ACTUAL      = 8
COL_TEST2_RESULT      = 9

# Result cell colours
FILL_PASS = PatternFill("solid", start_color="C6EFCE")
FILL_FAIL = PatternFill("solid", start_color="FFC7CE")
FONT_PASS = Font(name="Arial", size=10, bold=True, color="276221")
FONT_FAIL = Font(name="Arial", size=10, bold=True, color="9C0006")

# Fixed check definitions (locator + expected text)
CHECKS = [
    {
        "col_name":     COL_TEST1_NAME,
        "col_expected": COL_TEST1_EXPECTED,
        "col_actual":   COL_TEST1_ACTUAL,
        "col_result":   COL_TEST1_RESULT,
        "locator":      '[data-automation-test-id^="buy-box-promo"] p',
        "default_name": "Promo text",
    },
    {
        "col_name":     COL_TEST2_NAME,
        "col_expected": COL_TEST2_EXPECTED,
        "col_actual":   COL_TEST2_ACTUAL,
        "col_result":   COL_TEST2_RESULT,
        "locator":      "li:first-child div.collapse.show div.accordion-body p:nth-child(2)",
        "default_name": "Accordion AI text",
    },
]

print("🤖 Loading semantic model…")
_model = SentenceTransformer("all-MiniLM-L6-v2")
print("✅ Model ready\n")

os.makedirs(SCREENSHOT_DIR, exist_ok=True)


# ── Text helpers ──────────────────────────────────────────────────────────────

def normalize(text: str) -> str:
    return text.replace("\u00A0", " ").replace("\n", " ").strip().lower()


def semantic_score(a: str, b: str) -> float:
    ea = _model.encode(a, convert_to_tensor=True)
    eb = _model.encode(b, convert_to_tensor=True)
    return float(util.cos_sim(ea, eb))


# ── Language / translation ────────────────────────────────────────────────────

def detect_page_language(page: Page) -> str:
    html_lang: str = page.evaluate("document.documentElement.lang") or ""
    if html_lang:
        return html_lang.split("-")[0].lower()
    try:
        texts  = page.locator("p").all_inner_texts()
        sample = " ".join(t for t in texts[:10] if len(t) > 20)
        return langdetect.detect(sample) if sample else "unknown"
    except Exception:
        return "unknown"


def trigger_translate_via_ui(page: Page) -> bool:
    triggered = page.evaluate("""
        () => {
            if (window.cr && window.cr.googleTranslate) {
                window.cr.googleTranslate.translatePage('en');
                return 'cr.googleTranslate';
            }
            document.dispatchEvent(new CustomEvent('translate-page', {
                detail: { targetLang: 'en' }
            }));
            return 'custom-event';
        }
    """)
    print(f"  🌐 Translate triggered via: {triggered}")
    return True


def wait_for_translation(page: Page, src_lang: str) -> bool:
    print(f"  ⏳ Waiting for translation ({src_lang} → en)…")
    deadline = time.time() + TRANSLATION_TIMEOUT_S
    while time.time() < deadline:
        if detect_page_language(page) == "en":
            print("  ✅ Page is now in English")
            return True
        time.sleep(TRANSLATION_POLL_S)
    print(f"  ⚠️  Translation timed out after {TRANSLATION_TIMEOUT_S}s")
    return False


def ensure_english(page: Page) -> str:
    lang = detect_page_language(page)
    print(f"  🌐 Detected language: {lang!r}")
    if lang == "en":
        print("  ✅ Already English")
        return "original"
    page.wait_for_timeout(2000)
    trigger_translate_via_ui(page)
    if wait_for_translation(page, lang):
        page.wait_for_timeout(AFTER_TRANSLATE_WAIT)
        return "translated"
    return "failed"


def translate_element_text(text: str) -> str:
    try:
        from deep_translator import GoogleTranslator
        return GoogleTranslator(source="auto", target="en").translate(text) or text
    except Exception:
        return text


def get_text_for_matching(elem, idx: int) -> tuple[str, str]:
    """Returns (normalised_text_for_matching, raw_display_text)."""
    raw = elem.inner_text()
    try:
        lang = langdetect.detect(raw)
    except Exception:
        lang = "en"
    if lang != "en":
        print(f"    [#{idx}] Still {lang!r} — translating via deep_translator…")
        raw = translate_element_text(raw)
    return normalize(raw), raw


# ── Page actions ──────────────────────────────────────────────────────────────

def close_popup(page: Page, timeout: int = 5000):
    try:
        btn = page.locator('xpath=/html/body/div[2]/div[2]/div/div/div[1]/button')
        btn.wait_for(state="visible", timeout=timeout)
        btn.click()
        print("  ✅ Popup closed")
    except Exception:
        print("  ℹ️  No popup")


def expand_first_accordion(page: Page):
    try:
        btn = page.locator("button.btn-collapse").first
        btn.wait_for(state="visible", timeout=10_000)
        if btn.get_attribute("aria-expanded") != "true":
            btn.click()
            page.locator("div.collapse.show").first.wait_for(timeout=10_000)
        print("  ✅ Accordion expanded")
    except Exception as e:
        print(f"  ⚠️  Accordion expand failed: {e}")


def run_check(page: Page, locator_str: str, expected: str) -> tuple[bool, str]:
    """
    Run a single check. Returns (passed: bool, actual_text: str).
    actual_text is the best matching element's text (for writing back to Excel).
    """
    expected_norm = normalize(expected)
    locator = page.locator(locator_str)
    try:
        locator.first.wait_for(state="attached", timeout=10_000)
    except Exception:
        return False, "element not found"

    count = locator.count()
    best_score, best_idx, best_text = 0.0, -1, ""

    for i in range(count):
        elem = locator.nth(i)
        candidate, raw = get_text_for_matching(elem, i)

        if expected_norm in candidate:
            print(f"  [#{i}] ✅ Exact match")
            _highlight(elem, expected)
            return True, raw

        score = semantic_score(candidate, expected_norm)
        print(f"  [#{i}] score={score:.3f} | {candidate[:100]}")
        if score > best_score:
            best_score, best_idx, best_text = score, i, raw

    print(f"  Best semantic score: {best_score:.3f} (threshold {SEMANTIC_THRESHOLD})")
    if best_score >= SEMANTIC_THRESHOLD and best_idx >= 0:
        elem = locator.nth(best_idx)
        print(f"  [#{best_idx}] ✅ Semantic match accepted")
        _highlight_semantic(elem, expected)
        return True, best_text

    print("  ❌ No match")
    return False, best_text


def _highlight(elem, text: str):
    try:
        elem.evaluate(f"""
            el => {{
                const re = new RegExp({repr(text)}, 'gi');
                el.innerHTML = el.innerHTML.replace(re,
                    m => '<span style="background:yellow;border:2px solid red;border-radius:3px">' + m + '</span>');
            }}
        """)
    except Exception:
        pass


def _highlight_semantic(elem, label: str):
    try:
        elem.evaluate(f"""
            el => {{
                el.style.outline = '3px solid red';
                el.style.backgroundColor = 'lightyellow';
                const tag = document.createElement('span');
                tag.textContent = ' [✓ semantic match]';
                tag.style.cssText = 'background:red;color:white;font-size:11px;padding:1px 4px;border-radius:3px';
                el.appendChild(tag);
            }}
        """)
    except Exception:
        pass


# ── Excel helpers ─────────────────────────────────────────────────────────────

def write_result(ws, row: int, col_actual: int, col_result: int,
                 actual_text: str, passed: bool):
    ws.cell(row=row, column=col_actual).value = actual_text
    result_cell = ws.cell(row=row, column=col_result)
    result_cell.value = "PASS" if passed else "FAIL"
    result_cell.fill  = FILL_PASS if passed else FILL_FAIL
    result_cell.font  = FONT_PASS if passed else FONT_FAIL


# ── Chrome persistent profile setup ──────────────────────────────────────────

def setup_chrome_profile() -> str:
    profile_dir = str(pathlib.Path.home() / "chrome-playwright-profile")
    prefs_dir   = os.path.join(profile_dir, "Default")
    prefs_file  = os.path.join(prefs_dir, "Preferences")
    os.makedirs(prefs_dir, exist_ok=True)

    prefs = {}
    if os.path.exists(prefs_file):
        try:
            with open(prefs_file, "r", encoding="utf-8") as f:
                prefs = json.load(f)
        except Exception:
            prefs = {}

    translate_prefs = prefs.setdefault("translate", {})
    translate_prefs["enabled"] = True
    allowlists = translate_prefs.setdefault("translate_allowlists", {})
    for lang in ["ar", "fr", "de", "es", "it", "pt", "ja", "zh", "ko", "ru",
                 "tr", "nl", "pl", "sv", "da", "fi", "no", "he", "fa", "ur"]:
        allowlists[lang] = "en"

    with open(prefs_file, "w", encoding="utf-8") as f:
        json.dump(prefs, f)

    return profile_dir


# ── Main ──────────────────────────────────────────────────────────────────────

def run():
    if not os.path.exists(EXCEL_FILE):
        print(f"❌ Excel file not found: {EXCEL_FILE}")
        return

    wb = load_workbook(EXCEL_FILE)
    ws = wb.active

    # Collect rows: skip header (row 1), read until empty region
    regions = []
    for row in ws.iter_rows(min_row=2):
        region_val = row[COL_REGION - 1].value
        if not region_val:
            continue
        regions.append({
            "row":    row[0].row,
            "region": str(region_val).strip(),
        })

    if not regions:
        print("❌ No regions found in Excel. Add region codes in column A.")
        return

    print(f"📋 Found {len(regions)} region(s): {[r['region'] for r in regions]}\n")

    profile_dir = setup_chrome_profile()

    with sync_playwright() as p:
        browser: BrowserContext = p.chromium.launch_persistent_context(
            user_data_dir=profile_dir,
            channel="chrome",
            headless=False,
            slow_mo=100,
            args=["--enable-features=TranslateUI,ChromeTranslateUI", "--lang=en-US"],
            locale="en-US",
        )
        page = browser.pages[0] if browser.pages else browser.new_page()

        for entry in regions:
            region = entry["region"]
            row    = entry["row"]
            url    = BASE_URL.format(region=region)

            print(f"\n{'='*60}")
            print(f"▶  Region: {region}  →  {url}")
            print(f"{'='*60}")

            page.goto(url, wait_until="networkidle")
            close_popup(page)
            expand_first_accordion(page)
            ensure_english(page)

            page.add_style_tag(content=".highlighted{background:yellow;border:2px solid red;border-radius:3px}")

            all_passed = True
            for check_def in CHECKS:
                # Read expected text from Excel (fall back to empty string if blank)
                expected = ws.cell(row=row, column=check_def["col_expected"]).value or ""
                name     = ws.cell(row=row, column=check_def["col_name"]).value or check_def["default_name"]
                expected = str(expected).strip()

                print(f"\n  🔍 {name}")
                if not expected:
                    print(f"  ⚠️  No expected text in Excel for '{name}' — skipping")
                    ws.cell(row=row, column=check_def["col_result"]).value = "SKIPPED"
                    continue

                passed, actual = run_check(page, check_def["locator"], expected)
                write_result(ws, row, check_def["col_actual"], check_def["col_result"], actual, passed)

                status = "✅ PASS" if passed else "❌ FAIL"
                print(f"  {status}: {name}")
                if not passed:
                    all_passed = False

            # Screenshot named "PDP Family page {region}"
            screenshot_name = f"PDP Family page {region}.png"
            screenshot_path = os.path.join(SCREENSHOT_DIR, screenshot_name)
            page.screenshot(path=screenshot_path, full_page=True)
            print(f"\n  📌 Screenshot: {screenshot_path}")
            print(f"  {'🎉 All passed' if all_passed else '⚠️  Some checks failed'} for {region}")

        browser.close()

    wb.save(EXCEL_FILE)
    print(f"\n✅ Results written back to {EXCEL_FILE}")


if __name__ == "__main__":
    run()