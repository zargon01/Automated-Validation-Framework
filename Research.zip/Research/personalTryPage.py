from playwright.sync_api import sync_playwright
from langdetect import detect
from deep_translator import GoogleTranslator
from sentence_transformers import SentenceTransformer, util

# Expected meaning
EXPECTED_TEXT = "you also get extensive usage on advanced AI experiences"

# Load NLP model once
model = SentenceTransformer('all-MiniLM-L6-v2')


def translate_to_english(text: str) -> str:
    try:
        lang = detect(text)
        print(f"🌍 Detected language: {lang}")

        if lang != "en":
            translated = GoogleTranslator(source='auto', target='en').translate(text)
            print(f"🔁 Translated text: {translated}")
            return translated
        return text

    except Exception as e:
        print("⚠️ Translation failed:", e)
        return text


def semantic_match(text: str, expected: str, threshold: float = 0.6) -> bool:
    text_en = translate_to_english(text)

    emb1 = model.encode(text_en, convert_to_tensor=True)
    emb2 = model.encode(expected, convert_to_tensor=True)

    score = util.cos_sim(emb1, emb2).item()
    print(f"🧠 Similarity score: {score:.3f}")

    return score >= threshold


with sync_playwright() as p:
    browser = p.chromium.launch(headless=False)
    page = browser.new_page()

    page.goto(
        "https://www.microsoft.com/fr-be/microsoft-365/try-prs",
        wait_until="networkidle"
    )

    page.wait_for_selector("ul.accordion")

    locator = page.locator("ul.accordion li div div p").nth(1)
    locator.wait_for(timeout=10000)

    text = locator.inner_text()
    print("\n--- Extracted Text ---\n", text)

    is_match = semantic_match(text, EXPECTED_TEXT)

    # 🔴 ASSERTION (fails test if not matching)
    assert is_match, "❌ Text does NOT match expected meaning!"

    print("✅ Meaning matches expected content")

    # Highlight element
    locator.evaluate("""
        el => {
            el.style.border = '4px solid red';
            el.style.backgroundColor = 'yellow';
            el.scrollIntoView({behavior: 'smooth', block: 'center'});
        }
    """)

    page.wait_for_timeout(1500)

    # Full page screenshot
    page.screenshot(
        path="full_page.png",
        full_page=True
    )

    print("📸 Screenshot saved: full_page.png")

    browser.close()